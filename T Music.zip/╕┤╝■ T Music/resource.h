//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDC_PlayS                       2
#define IDC_NextS                       3
#define IDD_MAIN                        101
#define IDR_MENU1                       106
#define IDR_MENU2                       107
#define IDR_MENU3                       108
#define IDR_MENU4                       109
#define IDR_MENU5                       110
#define IDD_XMAIN                       112
#define IDB_BITMAP2                     115
#define IDB_BITMAP1                     117
#define IDB_BITMAP3                     118
#define IDB_BITMAP4                     120
#define IDB_BITMAP5                     121
#define IDC_OK                          1000
#define IDC_Pause                       1000
#define IDC_Last                        1001
#define IDC_Play                        1004
#define IDC_Listempty                   1005
#define IDC_Dormancy                    1006
#define IDC_ShutDown                    1007
#define IDC_Next                        1008
#define IDC_MusicLIST                   1009
#define IDC_PlayMode                    1010
#define IDC_Stop                        1011
#define IDC_CurrentMusic                1013
#define IDC_CurrentTime                 1014
#define IDC_AlarmClock                  1015
#define IDC_Hour                        1016
#define IDC_Minute                      1017
#define IDC_VolumeSLIDER                1019
#define IDC_TimeStart                   1020
#define IDC_Fvolume                     1021
#define IDC_ProgressSLIDER              1022
#define IDC_TimeEnd                     1023
#define IDC_PlayState                   1024
#define IDC_Del                         1025
#define IDC_Add                         1026
#define IDC_EDIT1                       1028
#define IDC_LastS                       1030
#define IDC_ClockAddress                1031
#define IDC_Net                         1033
#define IDC_MusicName                   1037
#define IDC_Singer                      1038
#define IDC_Album                       1039
#define IDC_OpenT                       40001
#define IDC_emptyT                      40003
#define IDC_QuitT                       40004
#define IDC_PlayT                       40005
#define IDC_LastT                       40007
#define IDC_NestT                       40008
#define IDC_NextM                       40008
#define ID_PauseT                       40011
#define IDC_PauseM                      40011
#define IDC_SingleCycleT                40013
#define IDC_ListCycleT                  40014
#define IDC_RandomPlayT                 40015
#define IDC_OpenCD                      40016
#define IDC_CloseCD                     40017
#define IDC_ShutDownT                   40018
#define IDC_DormancyT                   40019
#define IDC_About                       40020
#define IDC_Author                      40021
#define IDC_PauseT                      40022
#define IDC_StopT                       40023
#define IDC_NextT                       40024
#define IDC_SingleCircleT               40025
#define IDC_ListCircleT                 40026
#define IDC_OrderPlayT                  40029
#define IDC_QuitM                       40030
#define IDC_PlayM                       40031
#define IDC_LastM                       40032
#define IDC_StopM                       40034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        122
#define _APS_NEXT_COMMAND_VALUE         40035
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
